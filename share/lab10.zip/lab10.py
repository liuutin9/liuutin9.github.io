def word_freq(fname):
    fp = open(fname)
    counts = {} # Logic Error
    for line in fp:
        words = line.split()
        for word in words:
            counts[word] = 1 if word not in counts else counts[word] + 1 # Logic Error
    fp.close() # Logic Error
    return counts

if __name__ == '__main__':
    print(word_freq('sample.txt'))
    #{'here': 1, 'are': 2, 'some': 1, 'words': 4,
    # 'this': 2, 'line': 2, 'has': 1, 'more': 1, 'on': 1}

morse_dictionary = {'A': '.-', 'B': '-...', 'C': '-.-.',
'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.', 'H': '....', 
'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M': '--',
'N': '-.', 'O': '---', 'P': '.--.', 'Q': '--.-', 'R': '.-.',
'S': '...', 'T': '-', 'U': '..-', 'V': '...-', 'W': '.--',
'X': '-..-', 'Y': '-.--', 'Z': '--..', ' ': '/'}

def text_to_morse(text):
    text = text.upper()
    morse_code = ''
    for char in text:
        morse_code += morse_dictionary[char] + ' '
    return morse_code.strip()

print(text_to_morse('My TAs are amazing'))

costs = {'Philadelphia':{'Chicago':227, 'Dallas':289},
         'Chicago':{'Philadelphia':227, 'Dallas':105, 'Las Vegas':56},
         'Dallas':{'Philadelphia':289, 'Houston':173, 'Chicago':105,
                   'Las Vegas':44, 'San Diego':303},
         'Houston':{'Dallas':173},
         'Las Vegas':{'Chicago':56, 'Dallas':44, 'San Diego':74,
                      'Los Angeles':44, 'San Francisco':56},
         'Los Angeles':{'Las Vegas':44, 'San Diego':157,
                        'San Francisco':111},
         'San Diego':{'Las Vegas':44, 'Los Angeles':157, 'Dallas':303},
         'San Francisco':{'Las Vegas':56, 'Los Angeles':111}}

total = costs['Chicago']['Las Vegas'] + costs['Las Vegas']['Dallas']
print(total)

def cheapest(costs, origin, destination):
    if origin == destination:
        return 0
    minimum = float('inf')
    for city in costs[origin]:
        if city == destination and costs[origin][city] < minimum:
            minimum = costs[origin][destination]
        elif destination in costs[city]:
            total_cost = costs[origin][city] + costs[city][destination]
            if total_cost < minimum:
                minimum = total_cost
    return minimum

if __name__ == '__main__':
    print(cheapest(costs, 'San Francisco', 'Philadelphia')) #inf
    print(cheapest(costs, 'Chicago', 'Dallas')) #100
    print(cheapest(costs, 'Las Vegas', 'Los Angeles')) #44
    print(cheapest(costs, 'Philadelphia', 'Las Vegas')) #283

def rank_suit_count(cards):
    rank = {}
    suit = {}
    for card in cards:
        rank[card[0]] = 1 if card[0] not in rank else rank[card[0]] + 1
        suit[card[1]] = 1 if card[1] not in suit else suit[card[1]] + 1
    return rank, suit

if __name__ == '__main__':
    print(rank_suit_count(['AS','AD','2C','TH','TS']))
    #[{'A':2, '2':1, 'T':2}, {'S':2, 'D':1, 'C':1, 'H':1}]
        